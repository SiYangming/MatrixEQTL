

set -ex



plink2 --help | grep "PLINK v2.00a5.10"
exit 0
